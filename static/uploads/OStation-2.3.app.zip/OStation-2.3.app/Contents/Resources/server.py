import asyncio
from fastapi import FastAPI, Request, HTTPException, Depends, Header
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import OAuth2PasswordRequestForm
from jose import JWTError, jwt
from datetime import datetime, timedelta
from typing import Optional
import websockets
import uvicorn

# --- JWT 配置 ---
SECRET_KEY = "your_secret_key_here"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60

# --- 模拟的用户数据库 ---
fake_users_db = {
    "admin": {
        "username": "admin",
        "password": "admin123"  # 实际项目请加密密码！
    }
}

connected_clients = set()

app = FastAPI()

# CORS 允许前端网页访问
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # 可限制为你的网页地址
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# --- WebSocket 部分 ---
async def echo(websocket):
    connected_clients.add(websocket)
    print("🟢 客户端连接")
    try:
        await websocket.send("欢迎连接 WebSocket 服务！")
        async for message in websocket:
            print(f"📩 收到消息: {message}")
    except websockets.exceptions.ConnectionClosed:
        print("❌ 客户端断开连接")
    finally:
        connected_clients.remove(websocket)

async def start_websocket_server():
    server = await websockets.serve(echo, "0.0.0.0", 8765)
    print("✅ WebSocket 服务运行于 ws://localhost:8765")
    await server.wait_closed()

# --- JWT 工具函数 ---
def create_access_token(data: dict, expires_delta: timedelta = None):
    to_encode = data.copy()
    expire = datetime.utcnow() + (expires_delta or timedelta(minutes=15))
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)

def verify_token(token: str = Header(..., alias="Authorization")):
    if not token.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Invalid token format")
    token = token[7:]
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username: str = payload.get("sub")
        if username is None or username not in fake_users_db:
            raise HTTPException(status_code=401, detail="Invalid token")
        return username
    except JWTError:
        raise HTTPException(status_code=401, detail="Invalid token")

# --- 登录接口 ---
@app.post("/login")
async def login(form_data: OAuth2PasswordRequestForm = Depends()):
    user = fake_users_db.get(form_data.username)
    if not user or user["password"] != form_data.password:
        raise HTTPException(status_code=401, detail="用户名或密码错误")
    access_token = create_access_token(
        data={"sub": user["username"]},
        expires_delta=timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    )
    return {"access_token": access_token, "token_type": "bearer"}

# --- 广播接口 ---
async def broadcast_message(msg: str):
    for ws in connected_clients.copy():
        try:
            await ws.send(msg)
        except Exception as e:
            print(f"⚠️ 广播失败: {e}")

@app.post("/broadcast")
async def broadcast(req: Request, username: str = Depends(verify_token)):
    data = await req.json()
    msg = data.get("message", "")
    print(f"📢 用户 {username} 广播: {msg}")
    asyncio.create_task(broadcast_message(f"{username}: {msg}"))
    return {"status": "ok", "user": username, "message": msg}

# --- 启动 WebSocket + API ---
async def main():
    ws_task = asyncio.create_task(start_websocket_server())
    api_task = asyncio.create_task(uvicorn.run(app, host="0.0.0.0", port=8000))
    await asyncio.gather(ws_task, api_task)

if __name__ == "__main__":
    asyncio.run(main())
