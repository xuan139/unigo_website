# 🖥️ OStation 项目指南

> 一个 macOS 上的 Windows 应用辅助运行工具，支持版本管理与差分更新。


---

## 📦 分支说明

| 分支名称        | 描述          |
|---------------|---------------|
| `main`        | 主分支         |
| `releaseV1`   | 稳定发布版本    |

---

## 📥 克隆项目

### 克隆 `releaseV1` 分支

```bash
git clone -b releaseV1 https://github.com/xuan139/OStation.git
cd OStation
```

或使用如下命令：

```bash
git clone https://github.com/xuan139/OStation.git
cd OStation
git checkout releaseV1
```

---

## 📜 License

本项目使用 **[GNU General Public License v3.0](https://www.gnu.org/licenses/gpl-3.0.html)** 开源协议。

---

## 🍷 安装 Wine（运行 Windows 程序）

```bash
brew install --cask --no-quarantine wine-stable
wine --version
```

---

## 💡 Apple Silicon (M1/M2/M3) 用户注意

Wine 对 Apple Silicon（ARM 架构）原生支持有限，推荐以下解决方案：

### ✅ 推荐方式

- ✅ 安装 **Rosetta 2**（Apple 官方兼容层）
- ✅ 使用图形界面工具：  
  - [PlayOnMac](https://www.playonmac.org/)  
  - [CrossOver](https://www.codeweavers.com/crossover)

---

## 🧠 系统架构说明

| Mac 类型        | 架构     | 描述                                     |
|------------------|----------|------------------------------------------|
| Intel Mac         | x86      | 可直接运行大部分 Wine 工具               |
| Apple Silicon Mac | ARM      | 需通过 Rosetta 2 翻译执行 x86 程序指令   |

---

## 🔧 安装 Rosetta 2（Apple Silicon 用户必装）

### 安装命令：

```bash
softwareupdate --install-rosetta --agree-to-license
```

### 检查是否已安装：

```bash
/usr/bin/pgrep oahd >/dev/null && echo "✅ Rosetta 2 已安装" || echo "❌ Rosetta 2 未安装"
```

---

## 📂 示例路径（运行 Wine 程序）

若 `.app` 内嵌了 Windows 可执行程序（如 steam.exe）：

```bash
cd "/Volumes/Windows/System/SteamMetal.4.01.01.app/Contents/SharedSupport/prefix/drive_c/Program Files (x86)/Steam/"
wine steam.exe
```

> 若提示 `command not found: wine`，说明 Wine 未安装或未配置环境变量。

---

## ❓ 常见问题

- **Q: Wine 无法运行？**  
  A: 请确认你使用的是 Intel Mac，或 Apple Silicon 已安装 Rosetta 2。

- **Q: 启动 `.app` 后立即闪退？**  
  A: 检查 `Info.plist` 的 `LSUIElement`、`NSPrincipalClass`、可执行文件路径是否正确。

- **Q: `wine` 提示找不到？**  
  A: 确保你已经通过 `brew install` 安装 Wine，并配置好 `$PATH`。

---

## 🛠️ 相关命令备忘

- 查看 `.app` 的 `Info.plist`：

```bash
defaults read "/路径/xxx.app/Contents/Info.plist"
```

- 查找 `.app` 内的 `steam.exe`：

```bash
cd "xxx.app"
find . -iname "steam.exe"
```

---

## 📣 欢迎贡献

如有建议、功能需求或 bug，欢迎提交 issue 或 PR！

---

📘 项目地址：[https://github.com/xuan139/OStation](https://github.com/xuan139/OStation)


defaults read com.maks.com.OStation.plist

