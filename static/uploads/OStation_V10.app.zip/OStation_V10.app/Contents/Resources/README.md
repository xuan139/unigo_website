# OStation

---

## 📦 branches

| branch name | desc                        |
|-------------|------------------------------|
| `main`      | main         |
| `releaseV1` | stable       |

---

## 📥 clone branch

`releaseV1`

```bash
git clone -b releaseV1 https://github.com/xuan139/OStation.git
cd OStation

git clone https://github.com/xuan139/OStation.git
cd OStation
git checkout releaseV1

License
GPLv3
